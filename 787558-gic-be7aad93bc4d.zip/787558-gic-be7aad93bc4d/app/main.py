import sys
import os

current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

from app.models.cinema_hall import CinemaHall
from app.services.booking_service import BookingService
from app.services.display_service import DisplayService
from app.utils.input_validators import validate_movie_input, validate_ticket_input
from typing import Optional


class CinemaBookingSystem:
    """
    A class representing the main application for a cinema booking system.

    This class initializes and manages the cinema hall, booking service, and display service.
    It provides functionalities to book tickets, check bookings, and display the main menu.
    """
    
    def __init__(self):
        """
        Initialize the CinemaBookingSystem with empty cinema hall, booking service, and display service.
        """
        self.cinema_hall: Optional[CinemaHall] = None
        self.booking_service: Optional[BookingService] = None
        self.display_service: Optional[DisplayService] = None
    
    def initialize_cinema_hall(self) -> None:
        """
        Initialize cinema hall with user input.

        Prompts the user to input the movie title and seating arrangement.
        Validates the input and initializes the cinema hall, booking service, and display service.
        """
        while True:
            input_str = input("Please define movie title and seating map in [Title] [Row] [SeatsPerRow] format:\n> ")
            try:
                title, rows, seats_per_row = validate_movie_input(input_str)
                self.cinema_hall = CinemaHall(title, rows, seats_per_row)
                self.booking_service = BookingService(self.cinema_hall)
                self.display_service = DisplayService(self.cinema_hall)
                break
            except ValueError as e:
                print(f"Error: {e}. Please try again.")
    
    def display_main_menu(self) -> None:
        """
        Display the main menu options.

        Shows options to book tickets, check bookings, or exit the system.
        Raises a RuntimeError if the cinema hall is not initialized.
        """
        if not self.cinema_hall:
            raise RuntimeError("Cinema hall not initialized")
        
        print(f"\nWelcome to GIC Cinemas")
        print(f"[1] Book tickets for {self.cinema_hall.title} ({self.cinema_hall.get_available_seats()} seats available)")
        print("[2] Check bookings")
        print("[3] Exit")
    
    def book_tickets(self) -> None:
        """
        Handle ticket booking workflow.

        Prompts the user to input the number of tickets to book and processes the booking.
        """
        while True:
            num_tickets_input = input("\nEnter number of tickets to book, or enter blank to go back to main menu:\n> ").strip()
            if not num_tickets_input:
                return
            
            try:
                num_tickets = validate_ticket_input(num_tickets_input)
                if num_tickets == 0:
                    continue
                
                self._process_booking(num_tickets)
                return
            except ValueError as e:
                print(f"Error: {e}")
    
    def _process_booking(self, num_tickets: int) -> None:
        """
        Process a booking from start to confirmation.

        Args:
            num_tickets (int): The number of tickets to book.
        """
        available_seats = self.cinema_hall.get_available_seats()
        if num_tickets > available_seats:
            print(f"Sorry, there are only {available_seats} seats available.")
            return
        
        selected_seats = self.booking_service.find_default_seats(num_tickets)
        if len(selected_seats) != num_tickets:
            print("Error: Could not find enough seats")
            return
        
        booking_id = self.cinema_hall.generate_booking_id()
        self._confirm_booking(booking_id, selected_seats, num_tickets)
    
    def _confirm_booking(self, booking_id: str, selected_seats: list, num_tickets: int) -> None:
        """
        Handle seat selection confirmation process.

        Args:
            booking_id (str): The unique identifier for the booking.
            selected_seats (list): The list of seats selected for booking.
            num_tickets (int): The number of tickets booked.
        """
        while True:
            print(f"\nSuccessfully reserved {num_tickets} {self.cinema_hall.title} tickets.")
            print(f"Booking id: {booking_id}")
            print("Selected seats:")
            print(self.display_service.display_seating_map(selected_seats))
            
            new_position = input("\nEnter blank to accept seat selection, or enter the new seat position:\n> ").strip()
            if not new_position:
                self.booking_service.reserve_seats(booking_id, selected_seats)
                print(f"\nBooking id: {booking_id} confirmed.")
                return
            
            try:
                new_selected_seats = self.booking_service.find_seats_from_position(new_position, num_tickets)
                if len(new_selected_seats) == num_tickets:
                    selected_seats = new_selected_seats
                else:
                    print("Could not find enough seats starting from that position")
            except ValueError as e:
                print(f"Error: {e}")
    
    def check_bookings(self) -> None:
        """
        Handle booking checking workflow.

        Prompts the user to input a booking ID and displays the booking details.
        """
        while True:
            booking_id = input("\nEnter booking id, or enter blank to go back to main menu:\n> ").strip().upper()
            if not booking_id:
                return
            
            seats = self.cinema_hall.get_booking(booking_id)
            if not seats:
                print("Booking not found")
                continue
            
            print(f"\nBooking id: {booking_id}")
            print("Selected seats:")
            print(self.display_service.display_seating_map(seats))
    
    def run(self) -> None:
        """
        Run the main application loop.

        Initializes the cinema hall and displays the main menu.
        Handles user input to book tickets, check bookings, or exit the system.
        """
        self.initialize_cinema_hall()
        
        while True:
            self.display_main_menu()
            choice = input("Please enter your selection:\n> ").strip()
            
            if choice == "1":
                self.book_tickets()
            elif choice == "2":
                self.check_bookings()
            elif choice == "3":
                print("\nThank you for using GIC Cinemas system. Bye!")
                break
            else:
                print("Invalid selection. Please try again.")


if __name__ == "__main__":
    system = CinemaBookingSystem()
    system.run()