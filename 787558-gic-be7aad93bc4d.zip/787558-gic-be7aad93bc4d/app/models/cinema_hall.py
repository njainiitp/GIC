from typing import Dict, List, Optional
from app.models.seat import Seat


class CinemaHall:
    """Represents a cinema hall with seating arrangement and booking capabilities.

    Attributes:
        title (str): Name of the cinema hall.
        rows (int): Number of rows in the hall.
        seats_per_row (int): Number of seats per row.
        seats (Dict[str, Dict[int, Seat]]): Nested dictionary of seats organized by row and seat number.
        _bookings (Dict[str, List[Seat]]): Dictionary mapping booking IDs to lists of booked seats.
        booking_counter (int): Counter for generating unique booking IDs.
    """

    def __init__(self, title: str, rows: int, seats_per_row: int):
        """Initializes the CinemaHall with given parameters.

        Args:
            title: Name of the cinema hall.
            rows: Number of rows in the hall (max 26).
            seats_per_row: Number of seats per row (max 50).

        Raises:
            ValueError: If rows exceed 26 or seats_per_row exceed 50.
        """
        if rows > 26 or seats_per_row > 50:
            raise ValueError("Maximum rows is 26 and maximum seats per row is 50")
        
        self.title = title
        self.rows = rows
        self.seats_per_row = seats_per_row
        self.seats: Dict[str, Dict[int, Seat]] = {}
        self._bookings: Dict[str, List[Seat]] = {}
        self.booking_counter = 1
        self._initialize_seats()
    
    def _initialize_seats(self) -> None:
        """Initializes all seats in the cinema hall.
        
        Creates Seat objects for each position in the hall, organized by row (A-Z)
        and seat number (1-seats_per_row). Row A is considered furthest to the screen.
        """
        for row_num in range(self.rows):
            row_char = chr(ord('A') + row_num)
            self.seats[row_char] = {}
            for seat_num in range(1, self.seats_per_row + 1):
                self.seats[row_char][seat_num] = Seat(row_char, seat_num)
    
    def get_available_seats(self) -> int:
        """Counts and returns the number of available seats.
        
        A seat is considered available if it's neither booked nor currently
        being held in a pending booking.

        Returns:
            int: Total count of available seats in the hall.
        """
        return sum(
            1 for row in self.seats.values() 
            for seat in row.values() 
            if not seat.booked and not seat.current_booking
        )
    
    def generate_booking_id(self) -> str:
        """Generates a unique booking ID in the format GIC####.
        
        Increments the internal booking counter after each generation.

        Returns:
            str: Unique booking ID (e.g., 'GIC0001').
        """
        booking_id = f"GIC{self.booking_counter:04d}"
        self.booking_counter += 1
        return booking_id
    
    def get_booking(self, booking_id: str) -> Optional[List[Seat]]:
        """Retrieves seats associated with a booking ID.

        Args:
            booking_id: The booking ID to look up.

        Returns:
            Optional[List[Seat]]: List of seats for the booking if found, None otherwise.
        """
        return self._bookings.get(booking_id)
    
    def update_booking(self, booking_id: str, seats: List[Seat]) -> None:
        """Creates or updates a booking with the given seats.
        
        Args:
            booking_id: The booking ID to update.
            seats: List of Seat objects to associate with this booking.
        """
        self._bookings[booking_id] = seats
    
    def clear_current_bookings(self) -> None:
        """Resets all current_booking flags on all seats.
        
        This is typically used to clear temporary holds on seats after
        a booking session completes or expires.
        """
        for row in self.seats.values():
            for seat in row.values():
                seat.current_booking = False