from dataclasses import dataclass

@dataclass
class Seat:
    """Represents a single seat in a cinema hall.

    Attributes:
        row (str): The row identifier of the seat.
        number (int): The seat number within the row.
        booked (bool): Indicates whether the seat is booked. Defaults to False.
        current_booking (bool): Indicates whether the seat is currently being booked. Defaults to False.
    """

    row: str
    number: int
    booked: bool = False
    current_booking: bool = False

    def __str__(self) -> str:
        """Provides a string representation of the seat's status.

        Returns:
            str: 'X' if the seat is currently being booked, '#' if the seat is booked, otherwise '.'.
        """
        if self.current_booking:
            return 'X'
        elif self.booked:
            return '#'
        return '.'