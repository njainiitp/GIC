from typing import List, Dict, Tuple
from app.models.seat import Seat
from app.models.cinema_hall import CinemaHall
from app.utils.data_utils import sort_list_of_tuples, increment_row
import re


class BookingService:
    """Handles all booking-related operations"""
    
    def __init__(self, cinema_hall: CinemaHall):
        """Initialize BookingService with a given cinema hall.

        Args:
            cinema_hall (CinemaHall): The cinema hall for which bookings are managed.
        """
        self.cinema_hall = cinema_hall
    
    def find_default_seats(self, num_tickets: int, start_row: str = None) -> List[Seat]:
        """
        Find seats using default selection algorithm:
        - Start from furthest row (A)
        - Start from middle column
        - For overflow, move to next closer row (B, C,...)
        - Always select middle-most seats first in each row

        Args:
            num_tickets (int): Number of seats to find.
            start_row (str, optional): The row to start from. Defaults to None.

        Returns:
            List[Seat]: A list of selected seats.
        """
        selected_seats = []
        remaining_tickets = num_tickets
        
        # Process rows from furthest (A) to closest (Z)
        for row_char in sorted(self.cinema_hall.seats.keys()):
            if start_row and row_char < start_row:
                continue
            if remaining_tickets == 0:
                break

            # Find best seats in current row
            row = self.cinema_hall.seats[row_char]
            seats_in_row = self._find_fillable_seat_in_row(row)
            take = min(remaining_tickets, len(seats_in_row))
            selected_seats.extend(seats_in_row[:take])
            remaining_tickets -= take
        
        return selected_seats
    
    def _find_fillable_seat_in_row(self, row: Dict[int, Seat]):
        """
        Get list of unfilled seats in order such that the seats closer to middle position in row are sequenced first.

        Args:
            row (Dict[int, Seat]): A dictionary of seats in a row.

        Returns:
            List[Seat]: A list of fillable seats ordered by proximity to the middle.
        """

        vacant_indices = [seat_no for seat_no, seat in row.items() if self._is_seat_available(row, seat_no)]
    
        middle = (len(row) + 1) / 2

        def distance_from_middle(index):
            return abs(index - middle)

        sorted_indices = sorted(vacant_indices, key=lambda x: (distance_from_middle(x), x))

        fillable_seats = []
        for _, index in enumerate(sorted_indices):
            fillable_seats.append(row[index])

        return fillable_seats

    
    def _is_seat_available(self, row: Dict[int, Seat], seat_num: int) -> bool:
        """Check if seat is available for booking.

        Args:
            row (Dict[int, Seat]): A dictionary of seats in a row.
            seat_num (int): The seat number to check.

        Returns:
            bool: True if the seat is available, False otherwise.
        """
        return (seat_num in row and 
                not row[seat_num].booked)
    
    def find_seats_from_position(self, position: str, num_tickets: int) -> List[Seat]:
        """
        Find seats starting from specified position with overflow handling:
        1. Starts from specified position in specified row
        2. Fills all available seats to the right in same row
        3. For overflow, moves to next closer row (alphabetically higher)
        4. Overflow rows use middle-first selection (same as default)

        Args:
            position (str): The starting position to find seats from.
            num_tickets (int): Number of seats to find.

        Returns:
            List[Seat]: A list of selected seats.
        """
        selected_seats = []
        remaining_tickets = num_tickets
        
        try:
            row_char, inp_seat_num = self._parse_position(position)
        except ValueError as e:
            print(f"Error: {e}")
            return []
        
        # Process rows from specified row to closest (Z)
        row = self.cinema_hall.seats[row_char]
        selected_seats = [(seat_num, seat) for seat_num, seat in row.items() if
                           seat_num>=inp_seat_num and self._is_seat_available(row, seat_num)
                           ]
        selected_seats = sort_list_of_tuples(selected_seats, 0)
        selected_seats = [seat for _, seat in selected_seats]
        
        if len(selected_seats)>=remaining_tickets:
            return selected_seats[:remaining_tickets]
        else:
            remaining_tickets -= len(selected_seats)
            seats_selected_overflow = self.find_default_seats(remaining_tickets, start_row=increment_row(row_char,1))
        return selected_seats + seats_selected_overflow


    def _parse_position(self, position: str) -> Tuple[str, int]:
        """Parse and validate seat position string (e.g., 'A5' or 'B12').

        Args:
            position (str): The seat position string to parse.

        Returns:
            Tuple[str, int]: A tuple containing the row character and seat number.

        Raises:
            ValueError: If the position format is invalid or the row/seat does not exist.
        """
        match = re.match(r"^([A-Za-z])(\d{1,2})$", position.upper())
        if not match:
            raise ValueError("Invalid seat position format. Use format like 'A5' or 'B12'")
        
        row_char = match.group(1)
        col_num = int(match.group(2))
        
        if row_char not in self.cinema_hall.seats:
            raise ValueError(f"Row {row_char} does not exist")
        if not 1 <= col_num <= self.cinema_hall.seats_per_row:
            raise ValueError(f"Seat number must be between 1 and {self.cinema_hall.seats_per_row}")
        
        return row_char, col_num
    
    def reserve_seats(self, booking_id: str, seats: List[Seat]) -> None:
        """Mark seats as booked and store the booking.

        Args:
            booking_id (str): The ID of the booking.
            seats (List[Seat]): A list of seats to reserve.
        """
        for seat in seats:
            seat.booked = True
            seat.current_booking = False
        self.cinema_hall.update_booking(booking_id, seats)