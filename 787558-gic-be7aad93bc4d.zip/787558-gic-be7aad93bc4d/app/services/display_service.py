from typing import List, Optional
from app.models.seat import Seat
from app.models.cinema_hall import CinemaHall


class DisplayService:
    """Handles all display-related operations for a cinema hall seating arrangement."""
    
    def __init__(self, cinema_hall: CinemaHall):
        """Initialize the DisplayService with a specific cinema hall.

        Args:
            cinema_hall (CinemaHall): The cinema hall for which seating maps will be generated.
        """
        self.cinema_hall = cinema_hall
    
    def display_seating_map(self, highlight_seats: Optional[List[Seat]] = None) -> str:
        """Generate a seating map string with optional highlighted seats.

        Args:
            highlight_seats (Optional[List[Seat]]): A list of seats to highlight on the map.
                Defaults to None, indicating no seats to highlight.

        Returns:
            str: A string representation of the seating map.
        """
        highlight_seats = highlight_seats or []
        self._prepare_seats_for_display(highlight_seats)
        return self._build_seating_map()
    
    def _prepare_seats_for_display(self, highlight_seats: List[Seat]) -> None:
        """Reset and set current booking flags for display purposes.

        This method clears any previous current booking flags and sets new ones based on the provided list of seats.

        Args:
            highlight_seats (List[Seat]): A list of seats to be marked as currently booked.
        """
        self.cinema_hall.clear_current_bookings()
        for seat in highlight_seats:
            if seat.row in self.cinema_hall.seats and seat.number in self.cinema_hall.seats[seat.row]:
                self.cinema_hall.seats[seat.row][seat.number].current_booking = True
    
    def _build_seating_map(self) -> str:
        """Construct the seating map string representation.

        Returns:
            str: A formatted string representing the seating map, including the screen, rows, and seat numbers.
        """
        lines = []
        lines.append("\n                SCREEN                  ")
        lines.append("------------------------------------------")
        
        for row_char in sorted(self.cinema_hall.seats.keys(), reverse=True):
            lines.append(self._build_row_string(row_char))
        
        lines.append(self._build_seat_numbers())
        return "\n".join(lines)
    
    def _build_row_string(self, row_char: str) -> str:
        """Build a string representation of a single row of seats.

        Args:
            row_char (str): The character representing the row.

        Returns:
            str: A string representation of the row, including the row character and seat statuses.
        """
        row = self.cinema_hall.seats[row_char]
        seat_chars = [f"{row_char}   "]
        for seat_num in range(1, self.cinema_hall.seats_per_row + 1):
            seat = row[seat_num]
            seat_chars.append(f"{str(seat)}   ")
        return "".join(seat_chars)
    
    def _build_seat_numbers(self) -> str:
        """Build a string of seat numbers for the seating map.

        Returns:
            str: A string representation of seat numbers, aligned with the seating map.
        """
        seat_numbers = ["    "]
        for seat_num in range(1, self.cinema_hall.seats_per_row + 1):
            seat_numbers.append(f"{seat_num}   ")
        return "".join(seat_numbers)