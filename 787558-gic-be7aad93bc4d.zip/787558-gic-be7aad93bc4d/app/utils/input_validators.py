def validate_movie_input(input_str: str) -> tuple:
    """Validate initial movie input format"""
    parts = input_str.split()
    if len(parts) != 3:
        raise ValueError("Invalid input format")
    
    title = parts[0]
    try:
        rows = int(parts[1])
        seats_per_row = int(parts[2])
    except ValueError:
        raise ValueError("Rows and seats must be integers")
    
    if rows < 1 or seats_per_row < 1:
        raise ValueError("Rows and seats per row must be positive integers")
    if rows > 26:
        raise ValueError("Maximum number of rows is 26")
    if seats_per_row > 50:
        raise ValueError("Maximum number of seats per row is 50")
    
    return title, rows, seats_per_row


def validate_ticket_input(input_str: str) -> int:
    """Validate ticket number input"""
    if not input_str.strip():
        return 0
    
    try:
        num_tickets = int(input_str)
    except ValueError:
        raise ValueError("Please enter a valid number")
    
    if num_tickets <= 0:
        raise ValueError("Number of tickets must be positive")
    
    return num_tickets