from typing import List


def sort_list_of_tuples(l: List, idx):
    return list(sorted(l, key=lambda x: x[idx]))

def increment_row(row_char: str, step: int):
    return chr(ord(row_char)+step)
