
# Cinema Booking System - Design Document

## Overview
A cinema ticket booking system that handles seat selection, reservations, and booking management with:
- Middle-first seat selection algorithm
- Position-based seat selection
- Overflow handling between rows
- Booking confirmation and viewing

## System Architecture

### Core Components
```text
app/
├── models/            # Data models and business logic
│   ├── seat.py        # Seat representation
│   └── cinema_hall.py # Cinema hall configuration
├── services/          # Business logic services
│   ├── booking_service.py # Seat selection algorithms
│   └── display_service.py # Seat map visualization
├── utils/             # Helper utilities
│   └── input_validators.py # Input validation
|   └── data_utils.py # utilities for data transformation
└── main.py           # Main application entry point
```

## Class Diagram

```mermaid
classDiagram
    class Seat {
        +str row
        +int number
        +bool booked
        +bool current_booking
        +__str__()
    }

    class CinemaHall {
        +str title
        +int rows
        +int seats_per_row
        +dict seats
        +dict bookings
        +get_available_seats()
        +generate_booking_id()
        +get_booking()
        +update_booking()
        +clear_current_bookings()
    }

    class BookingService {
        +find_default_seats(num_tickets)
        +find_seats_from_position(position, num_tickets)
        +reserve_seats(booking_id, seats)
        -_find_middle_segment()
        -_find_seats_to_right()
    }

    class DisplayService {
        +display_seating_map(highlight_seats)
        -_build_seating_map()
    }

    class CinemaBookingSystem {
        +initialize_cinema_hall()
        +book_tickets()
        +check_bookings()
        +run()
    }

    Seat "1" -- "*" CinemaHall
    CinemaHall "1" -- "1" BookingService
    CinemaHall "1" -- "1" DisplayService
    BookingService ..> Seat
    DisplayService ..> Seat
    CinemaBookingSystem --> BookingService
    CinemaBookingSystem --> DisplayService
```

## Key Classes

### 1. Seat (`models/seat.py`)
- Represents an individual cinema seat
- Tracks booking status through `booked` and `current_booking` flags
- String representation shows seat status (available, booked, selected)

### 2. CinemaHall (`models/cinema_hall.py`)
- Manages the physical cinema layout
- Contains all seats organized by row
- Handles booking ID generation
- Maintains dictionary of all bookings

### 3. BookingService (`services/booking_service.py`)
#### Core Methods:
- `find_default_seats()`: Middle-first selection algorithm
- `find_seats_from_position()`: Position-based selection
- `reserve_seats()`: Finalizes booking

#### Selection Algorithms:
1. **Default Selection**:
   - Starts from furthest row (A)
   - Selects middle-most available seats
   - Overflows to closer rows when needed

2. **Position-Based Selection**:
   - Starts from specified seat
   - Fills right in same row
   - Overflows to closer rows with middle-first selection

### 4. DisplayService (`services/display_service.py`)
- Visualizes seating map with screen at top
- Shows different markers for:
  - Available seats (.)
  - Booked seats (#)
  - Currently selected seats (X)

### 5. CinemaBookingSystem (`main.py`)
- Main application controller
- Handles user interaction flow
- Coordinates between services

## Key Algorithms

### Middle-First Seat Selection
1. Calculate middle column (right-of-center for even numbers)
2. Search outward in both directions
3. Prioritize perfectly centered seats in a row

### Position-Based Selection
1. Parse and validate starting position
2. Take all available seats to the right
3. For overflow:
   - Move to next closer row (alphabetically higher)
   - Use middle-first selection
4. Continue until all tickets allocated or no seats left

## Assumptions

1. **Cinema Layout**:
   - Maximum 26 rows (A-Z)
   - Maximum 50 seats per row
   - Row A is furthest from screen
   - Row Z is closest to screen

2. **Booking Rules**:
   - Start from the row furthest from the screen
   - Start filling the seat from the middle in a given row

3. **User Experience**:
   - Single movie at a time
   - No user accounts - booking ID based
   - No payment processing

## Enhancement Opportunities

### For Production Use
1. **Persistence Layer**:
   ```python
   # Suggested database models
   class Movie:
       title: str
       showtimes: List[datetime]
       
   class Screening:
       movie: Movie
       hall: CinemaHall
       time: datetime
   ```

2. **Additional Features**:
   - Multiple showtimes per movie
   - User accounts and booking history
   - Seat pricing tiers
   - Online payment integration
   - Admin interface for management

3. **Scalability Improvements**:
   - Redis caching for seat availability
   - Queue system for high demand bookings
   - Distributed locking for seat reservations

4. **Real-World Considerations**:
   - Wheelchair accessible seats
   - Group booking discounts
   - Seat reservation timeout (e.g., 15 minutes to pay)
   - Email/SMS confirmation

## Getting Started

### Set Working Directory for Project
```bash
cd gic
```

### Packages Installation
```bash
pip install -r requirements.txt
```

### Run the Application
```bash
cd gic
python ./app/main.py
```

### Example Usage
```
Please define movie title and seating map in [Title] [Row] [SeatsPerRow] format:
> Inception 5 10

Welcome to GIC Cinemas
[1] Book tickets for Inception (50 seats available)
[2] Check bookings
[3] Exit
> 1

Enter number of tickets to book:
> 4
```

## Testing Strategy
1. Unit tests for selection algorithms
2. Integration tests for booking workflow
3. Edge cases:
   - Single seat booking
   - Full row booking
   - Overflow scenarios
   - Invalid position formats
