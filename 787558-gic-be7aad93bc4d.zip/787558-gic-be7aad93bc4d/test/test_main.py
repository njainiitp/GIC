import pytest
from unittest.mock import patch, MagicMock
from io import StringIO
from app.main import CinemaBookingSystem  # Updated import path

class TestCinemaBookingSystem:
    """Test suite for CinemaBookingSystem class"""

    @pytest.fixture
    def system(self):
        """Fixture providing a clean system instance"""
        return CinemaBookingSystem()

    def test_initialize_cinema_hall_success(self, system):
        """Test successful cinema hall initialization"""
        test_input = "Avengers 5 10"
        expected_title = "Avengers"
        expected_rows = 5
        expected_seats = 10

        with patch('builtins.input', return_value=test_input), \
             patch('app.utils.input_validators.validate_movie_input') as mock_validate:
            
            mock_validate.return_value = (expected_title, expected_rows, expected_seats)
            system.initialize_cinema_hall()

            assert system.cinema_hall is not None
            assert system.cinema_hall.title == expected_title
            assert system.cinema_hall.rows == expected_rows
            assert system.cinema_hall.seats_per_row == expected_seats
            assert system.booking_service is not None
            assert system.display_service is not None

    def test_initialize_cinema_hall_retry(self, system):
        """Test retry logic for invalid initialization"""
        test_inputs = ["Invalid", "Avengers 5 10"]
        
        with patch('builtins.input', side_effect=test_inputs), \
             patch('app.utils.input_validators.validate_movie_input') as mock_validate, \
             patch('sys.stdout', new=StringIO()) as fake_out:
            
            # First call raises error, second succeeds
            mock_validate.side_effect = [ValueError("Invalid format"), ("Avengers", 5, 10)]
            system.initialize_cinema_hall()

            output = fake_out.getvalue()
            assert "Error: Invalid input format" in output
            assert system.cinema_hall is not None

    def test_display_main_menu(self, system):
        """Test main menu display"""
        with patch('app.models.cinema_hall.CinemaHall') as mock_hall, \
             patch('sys.stdout', new=StringIO()) as fake_out:
            
            mock_hall_instance = mock_hall.return_value
            mock_hall_instance.title = "Avengers"
            mock_hall_instance.get_available_seats.return_value = 50
            system.cinema_hall = mock_hall_instance
            
            system.display_main_menu()
            
            output = fake_out.getvalue()
            assert "Welcome to GIC Cinemas" in output
            assert "Avengers" in output
            assert "50 seats available" in output

    def test_book_tickets_workflow(self, system):
        """Test complete ticket booking workflow"""
        test_inputs = [
            "2",        # Number of tickets
            "",         # Accept default seats
            "3"         # Exit
        ]
        
        with patch('builtins.input', side_effect=test_inputs), \
             patch('app.models.cinema_hall.CinemaHall') as mock_hall, \
             patch('app.services.booking_service.BookingService') as mock_service, \
             patch('sys.stdout', new=StringIO()) as fake_out:
            
            # Setup mocks
            mock_hall_instance = mock_hall.return_value
            mock_hall_instance.title = "Avengers"
            mock_hall_instance.get_available_seats.return_value = 50
            mock_hall_instance.generate_booking_id.return_value = "ABC123"
            
            mock_service_instance = mock_service.return_value
            mock_service_instance.find_default_seats.return_value = ["A1", "A2"]
            
            system.cinema_hall = mock_hall_instance
            system.booking_service = mock_service_instance
            system.display_service = MagicMock()
            
            # Run the booking process
            system.book_tickets()
            
            # Verify outputs
            output = fake_out.getvalue()
            assert "Successfully reserved 2 Avengers tickets" in output
            assert "Booking id: ABC123" in output
            mock_service_instance.reserve_seats.assert_called_once_with("ABC123", ["A1", "A2"])

    def test_check_bookings_workflow(self, system):
        """Test booking checking workflow"""
        test_inputs = [
            "ABC123",   # Valid booking ID
            "",         # Return to menu
            "3"         # Exit
        ]
        
        with patch('builtins.input', side_effect=test_inputs), \
             patch('app.models.cinema_hall.CinemaHall') as mock_hall, \
             patch('app.services.display_service.DisplayService') as mock_display, \
             patch('sys.stdout', new=StringIO()) as fake_out:
            
            # Setup mocks
            mock_hall_instance = mock_hall.return_value
            mock_hall_instance.get_booking.return_value = ["A1", "A2"]
            
            mock_display_instance = mock_display.return_value
            mock_display_instance.display_seating_map.return_value = "Seat Map"
            
            system.cinema_hall = mock_hall_instance
            system.display_service = mock_display_instance
            
            # Run the check bookings process
            system.check_bookings()
            
            # Verify outputs
            output = fake_out.getvalue()
            assert "Booking id: ABC123" in output
            assert "Selected seats:" in output
            assert "Seat Map" in output

    def test_run_application(self, system):
        """Test complete application run"""
        test_inputs = [
            "Avengers 5 10",  # Initialize cinema
            "1",               # Book tickets
            "2",               # 2 tickets
            "",                # Accept seats
            "3"                # Exit
        ]
        
        with patch('builtins.input', side_effect=test_inputs), \
             patch('sys.stdout', new=StringIO()) as fake_out, \
             patch('app.models.cinema_hall.CinemaHall') as mock_hall, \
             patch('app.services.booking_service.BookingService') as mock_service:
            
            # Setup mocks
            mock_hall_instance = mock_hall.return_value
            mock_hall_instance.title = "Avengers"
            mock_hall_instance.get_available_seats.return_value = 50
            mock_hall_instance.generate_booking_id.return_value = "ABC123"
            
            mock_service_instance = mock_service.return_value
            mock_service_instance.find_default_seats.return_value = ["A1", "A2"]
            
            # Run the application
            system.run()
            
            # Verify final output
            output = fake_out.getvalue()
            assert "Welcome to GIC Cinemas" in output
            assert "Thank you for using GIC Cinemas system" in output