from app.utils.data_utils import sort_list_of_tuples, increment_row

def test_sort_list_of_tuples():
    data = [(2, 'b'), (1, 'a'), (3, 'c')]
    sorted_data = sort_list_of_tuples(data, 0)
    assert sorted_data == [(1, 'a'), (2, 'b'), (3, 'c')]
    sorted_data_1 = sort_list_of_tuples(data, 1)
    assert sorted_data_1 == [(1, 'a'), (2, 'b'), (3, 'c')]

def test_increment_row():
    assert increment_row('A', 1) == 'B'
    assert increment_row('A', 2) == 'C'
    assert increment_row('Z', 1) == '['  # Next ASCII after 'Z'
    assert increment_row('C', -2)