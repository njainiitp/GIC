import pytest
from app.models.cinema_hall import CinemaHall
from app.services.booking_service import BookingService

@pytest.fixture
def cinema_hall():
    hall = CinemaHall("Test Movie", 3, 5)
    # Mark some seats as booked for testing
    hall.seats['A'][3].booked = True
    hall.seats['B'][2].booked = True
    return hall

@pytest.fixture
def booking_service(cinema_hall):
    return BookingService(cinema_hall)

def test_find_default_seats_basic(booking_service):
    seats = booking_service.find_default_seats(2)
    assert len(seats) == 2
    # should fill middle most first
    assert seats[0].row == 'A'
    assert seats[0].number == 2
    assert seats[1].row == 'A'
    assert seats[1].number == 4
    # Should not include booked seats
    assert all(not seat.booked for seat in seats)

def test_find_default_seats_with_start_row(booking_service):
    seats = booking_service.find_default_seats(2, start_row='B')
    assert all(seat.row >= 'B' for seat in seats)

def test_find_default_seats_not_enough(booking_service):
    # Book all but one seat
    for row in booking_service.cinema_hall.seats.values():
        for seat in row.values():
            seat.booked = True
    booking_service.cinema_hall.seats['C'][5].booked = False
    seats = booking_service.find_default_seats(2)
    assert len(seats) == 1

def test_find_seats_from_position_exact(booking_service):
    seats = booking_service.find_seats_from_position('A1', 2)
    assert len(seats) == 2
    assert seats[0].row == 'A' and seats[0].number == 1

def test_find_seats_from_position_overflow(booking_service):
    # Book all seats in A except A5
    for num in range(1, 5):
        booking_service.cinema_hall.seats['A'][num].booked = True
    seats = booking_service.find_seats_from_position('A1', 3)
    # Should include A5 and then move to next row
    assert any(seat.row == 'B' for seat in seats)
    assert len(seats) == 3

def test_parse_position_valid(booking_service):
    row, num = booking_service._parse_position('B4')
    assert row == 'B'
    assert num == 4

def test_parse_position_invalid(booking_service):
    with pytest.raises(ValueError):
        booking_service._parse_position('Z99')
    with pytest.raises(ValueError):
        booking_service._parse_position('1A')
    with pytest.raises(ValueError):
        booking_service._parse_position('')

def test_reserve_seats(booking_service):
    seats = booking_service.find_default_seats(2)
    booking_id = booking_service.cinema_hall.generate_booking_id()
    booking_service.reserve_seats(booking_id, seats)
    stored = booking_service.cinema_hall.get_booking(booking_id)
    assert stored == seats
    # Seats should be marked as booked
    assert all(seat.booked for seat in seats)