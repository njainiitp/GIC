import pytest
from app.models.cinema_hall import CinemaHall
from app.services.display_service import DisplayService
from app.models.seat import Seat

@pytest.fixture
def cinema_hall():
    hall = CinemaHall("Test Movie", 2, 3)
    return hall

@pytest.fixture
def display_service(cinema_hall):
    return DisplayService(cinema_hall)

def test_display_seating_map_basic(display_service):
    output = display_service.display_seating_map()
    # Should contain screen, rows, and seat numbers
    assert "SCREEN" in output
    assert "A" in output
    assert "B" in output
    assert "1" in output and "2" in output and "3" in output

def test_display_seating_map_highlight(display_service, cinema_hall):
    seat = cinema_hall.seats['A'][2]
    output = display_service.display_seating_map([seat])
    # Highlighted seat should be marked as 'X'
    lines = output.splitlines()
    found = any('X' in line for line in lines)
    assert found

def test_prepare_seats_for_display_sets_current_booking(display_service, cinema_hall):
    seat = cinema_hall.seats['A'][1]
    display_service._prepare_seats_for_display([seat])
    assert seat.current_booking

def test_prepare_seats_for_display_resets_previous(display_service, cinema_hall):
    seat1 = cinema_hall.seats['A'][1]
    seat2 = cinema_hall.seats['B'][2]
    seat1.current_booking = True
    display_service._prepare_seats_for_display([seat2])
    assert not seat1.current_booking
    assert seat2.current_booking

def test_build_row_string(display_service, cinema_hall):
    row_str = display_service._build_row_string('A')
    # Should start with row letter and have correct number of seats
    assert row_str.startswith('A')
    assert row_str.count('.') == cinema_hall.seats_per_row

def test_build_seat_numbers(display_service, cinema_hall):
    seat_numbers = display_service._build_seat_numbers()
    for i in range(1, cinema_hall.seats_per_row + 1):
        assert str(i) in seat_numbers