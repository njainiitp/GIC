import pytest
from app.models.cinema_hall import CinemaHall
from app.models.seat import Seat

def test_initialize_seats():
    hall = CinemaHall("Test Movie", 3, 5)
    assert hall.title == "Test Movie"
    assert hall.rows == 3
    assert hall.seats_per_row == 5
    assert len(hall.seats) == 3
    assert all(len(row) == 5 for row in hall.seats.values())

def test_max_rows_and_seats():
    with pytest.raises(ValueError):
        CinemaHall("TooManyRows", 27, 10)
    with pytest.raises(ValueError):
        CinemaHall("TooManySeats", 5, 51)

def test_get_available_seats():
    hall = CinemaHall("Test", 2, 2)
    assert hall.get_available_seats() == 4
    # Book one seat
    seat = hall.seats['A'][1]
    seat.booked = True
    assert hall.get_available_seats() == 3

def test_generate_booking_id():
    hall = CinemaHall("Test", 1, 1)
    assert hall.generate_booking_id() == "GIC0001"
    assert hall.generate_booking_id() == "GIC0002"

def test_book_and_get_booking():
    hall = CinemaHall("Test", 1, 2)
    booking_id = hall.generate_booking_id()
    seats = [hall.seats['A'][1], hall.seats['A'][2]]
    hall.update_booking(booking_id, seats)
    assert hall.get_booking(booking_id) == seats
    assert hall.get_booking("INVALID") is None

def test_clear_current_bookings():
    hall = CinemaHall("Test", 1, 2)
    hall.seats['A'][1].current_booking = True
    hall.clear_current_bookings()
    assert not hall.seats['A'][1].current_booking