from app.models.seat import Seat

def test_seat_default_status():
    seat = Seat(row='A', number=1)
    assert seat.row == 'A'
    assert seat.number == 1
    assert seat.booked is False
    assert seat.current_booking is False
    assert str(seat) == '.'

def test_seat_str_current_booking():
    seat = Seat(row='B', number=2, current_booking=True)
    assert str(seat) == 'X'

def test_seat_str_booked():
    seat = Seat(row='C', number=3, booked=True)
    assert str(seat) == '#'

def test_seat_str_priority_current_booking_over_booked():
    seat = Seat(row='D', number=4, booked=True, current_booking=True)
    # current_booking should take precedence
    assert str(seat) == 'X'