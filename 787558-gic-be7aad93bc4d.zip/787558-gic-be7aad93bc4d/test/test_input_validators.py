import pytest
from app.utils.input_validators import validate_movie_input, validate_ticket_input

def test_validate_movie_input_valid():
    assert validate_movie_input("Movie_Title 5 10") == ("Movie_Title", 5, 10)

def test_validate_movie_input_invalid_format():
    with pytest.raises(ValueError):
        validate_movie_input("Movie Title 5 10")
    with pytest.raises(ValueError):
        validate_movie_input("Movie Title, five, ten")
    with pytest.raises(ValueError):
        validate_movie_input("Movie Title, 5, 10")
    with pytest.raises(ValueError):
        validate_movie_input("")

def test_validate_ticket_input_valid():
    assert validate_ticket_input("3") == 3
    assert validate_ticket_input("") == 0

def test_validate_ticket_input_invalid():
    with pytest.raises(ValueError):
        validate_ticket_input("zero")
    with pytest.raises(ValueError):
        validate_ticket_input("-1")
